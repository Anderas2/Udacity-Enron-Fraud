# -*- coding: utf-8 -*-
"""
This is a partial copy from the poi_id code. It contains mainly display code
for the data investigationd done during different project phases.

@author: tha2w1
"""


import sys
import pickle
sys.path.append("../tools/")

from feature_format import featureFormat, targetFeatureSplit
from tester import dump_classifier_and_data
import helper_functions

features_list = ['poi',
                 'salary', 'deferral_payments', 'deferred_income',
                 'exercised_stock_options','expenses', 'long_term_incentive',

                 'from_poi_to_this_person', 'from_this_person_to_poi',
                 'shared_receipt_with_poi'
                 ]

### Load the dictionary containing the dataset
with open("final_project_dataset.pkl", "rb") as data_file:
    data_dict = pickle.load(data_file)


my_dataset = data_dict

### Extract features and labels from dataset for local testing
data = featureFormat(my_dataset, features_list, sort_keys = True)
labels, features = targetFeatureSplit(data)
import numpy as np
X = np.array(features)
helper_functions.print2d(X, 0, 1)
### Task 4: Try a varity of classifiers